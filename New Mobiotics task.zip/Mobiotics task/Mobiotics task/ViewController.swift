//
//  ViewController.swift
//  Mobiotics task
//
//  Created by adithya on 1/30/19.
//  Copyright © 2019 adithya. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        //test string1: an apple laaptopp
        //test string2: a1n1 1a1p2l1e1 1l1a2p1t1o1p2
        
        
    }

    @IBAction func encrypt(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ResultViewController")as! ResultViewController
        vc.strLvl = "encrypt"
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func decrypt(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ResultViewController")as! ResultViewController
        vc.strLvl = "decrypt"

        self.navigationController?.pushViewController(vc, animated: true)

    }
}

