//
//  ResultViewController.swift
//  Mobiotics task
//
//  Created by adithya on 1/30/19.
//  Copyright © 2019 adithya. All rights reserved.
//

import UIKit

class ResultViewController: UIViewController {
    var strLvl = ""
    @IBOutlet var Lbl: UILabel!
    @IBOutlet var txt: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        if strLvl == "encrypt"{
            title = "encrypt"

        }else if strLvl == "decrypt"{
            title = "decrypt"
            
        }
        // Do any additional setup after loading the view.
        
        
    }
    
    func encrypt(string: String) -> String {
        
        let arrayOfChars = Array(string)
        var newString = String()
        
        var duplicatedCharCount = 1
        
        for i in 0..<arrayOfChars.count - 1  {
            
            if arrayOfChars[i] == arrayOfChars[i+1] {
                duplicatedCharCount += 1
            } else {
                newString.append(arrayOfChars[i])
                newString.append("\(duplicatedCharCount)")
                duplicatedCharCount = 1
            }
            
        }
        
        newString.append(arrayOfChars.last!)
        newString.append("\(duplicatedCharCount)")
        
        return newString
    }
    
    func decrypt(string: String) -> String {
        let arrayOfChars = Array(string)
        var newString = String()
        
        for i in 0..<arrayOfChars.count / 2 {
            
            let charIndex = i * 2
            let quantityIndex = charIndex + 1
            
            let character = arrayOfChars[charIndex]
            guard let quantity = Int(String(arrayOfChars[quantityIndex])) else { return "" }
            
            for _ in 0..<quantity {
                newString.append(character)
            }
            
        }
        
        return newString
    }
   
    @IBAction func result(_ sender: Any) {
        
        if strLvl == "encrypt"{
            //encrypt////
            let originalString = txt.text
            let newString = encrypt(string: originalString ?? "")
            print(newString)
            Lbl.text = newString

        }
        else if strLvl == "decrypt"
        {
            //decrypt//
            let myString =  txt.text
            let formattedString = decrypt(string: myString ?? "")
            print(formattedString)
            Lbl.text = formattedString
            
        }

    }
}
